import torch.nn as nn
import torch
import torch.nn.functional as F
import time
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from torchvision.datasets import ImageFolder
import matplotlib.pyplot as plt

from utils_for_present2 import disentangleKey, convertToOneHot, normalize, generateOneHot, displaySamples, reverseOneHot, generateLabel4CE

from tkinter import Variable
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import numpy as np
from PIL import Image
import os
import cv2
import torch.nn as nn
import torch.optim as optim
import torch.utils.data
import torch.nn.functional as F
import json
from torch.utils.tensorboard import SummaryWriter
from Main_Net import Comprehensive_Atten_Unet

from dice_losscopy2 import dice_loss

#temp_dir="/media/wpgao/Data3/data_endovis17/tmp"
#copy from 12.4
#temp_dir = 'E:/data_endovis17/tmp'

temp_dir = '/media/deep/instrument_seg/copy_of_2e419_2023.11.23_all_files/new_workplace_2023_for_Surg_Net/tmp'


import math
import numpy as np
import random
from PIL import Image
 
import torch
from torchvision import transforms as T
from torchvision.transforms import functional as F
 

class Resize(object):
    def __init__(self, size):
        self.size = size
 
    def __call__(self, image, target=None):
        image = F.resize(image, self.size)
        if target is not None:
            target = F.resize(target, self.size, interpolation=F.InterpolationMode.NEAREST)
        return image, target
 
 
class RandomHorizontalFlip(object):
    def __init__(self, flip_prob):
        self.flip_prob = flip_prob
 
    def __call__(self, image, target=None):
        if random.random() < self.flip_prob:
            image = F.hflip(image)
            if target is not None:
                target = F.hflip(target)
        return image, target

class RandomVerticalFlip(object):
    def __init__(self, flip_prob):
        self.flip_prob = flip_prob
 
    def __call__(self, image, target=None):
        if random.random() < self.flip_prob:
            image = F.vflip(image)
            if target is not None:
                target = F.vflip(target)
        return image, target

class RandomRotation(object):
    def __init__(self, rotation_prob):
        self.rotation_prob = rotation_prob
 
    def __call__(self, image, target=None):
        degree = random.random() * self.rotation_prob
        image = F.rotate(image,degree)
        if target is not None:
            target = F.rotate(target,degree)
        return image, target
 
class RandomCrop(object):
    def __init__(self, size):
        self.size = size

    def __call__(self, image, target):
        crop_params = T.RandomCrop.get_params(image, self.size)
        image = F.crop(image, *crop_params)
        if target is not None:
            target = F.crop(target, *crop_params)
        return image, target
 
class CenterCrop(object):
    def __init__(self, size):
        self.size = size
 
    def __call__(self, image, target):
        image = F.center_crop(image, self.size)
        if target is not None:
            target = F.center_crop(target, self.size)
        return image, target
 
class Normalize(object):
    def __init__(self, mean, std):
        self.mean = mean
        self.std = std
 
    def __call__(self, image, target):
        image = F.normalize(image, mean=self.mean, std=self.std)
        return image, target
 
class Pad(object):
    def __init__(self, padding_n, padding_fill_value=0, padding_fill_target_value=0):
        self.padding_n = padding_n
        self.padding_fill_value = padding_fill_value
        self.padding_fill_target_value = padding_fill_target_value
 
    def __call__(self, image, target):
        image = F.pad(image, self.padding_n, self.padding_fill_value)
        if target is not None:
            target = F.pad(target, self.padding_n, self.padding_fill_target_value)
        return image, target
 
class ToTensor(object):
    def __call__(self, image, target):
        image = F.to_tensor(image)
        if target is not None:
            target = torch.as_tensor(np.array(target), dtype=torch.float32)/255.0
        return image, target

class Compose(object):
    def __init__(self, transforms):
        self.transforms = transforms
 
    def __call__(self, image, mask=None):
        for t in self.transforms:
            image, mask = t(image, mask)
        return image,mask


class Evaluate():
    
    def __init__(self, num_classes, use_gpu):
        self.num_classes = num_classes
        self.use_gpu = use_gpu
        self.reset()
    
    def reset(self):
        self.tp = 0
        self.fp = 0
        self.fn = 0

    def addBatch(self, seg, gt):
        seg = convertToOneHot(seg, self.use_gpu).byte()
        seg = seg.float()
        gt = gt.float()
    
        if not self.use_gpu:
            seg = seg.cuda()
            gt = gt.cuda()
        
        tpmult = seg * gt
        tp = torch.sum(torch.sum(torch.sum(tpmult, dim = 0, keepdim = True), dim = 2, keepdim = True), dim = 3, keepdim = True).squeeze()
        fpmult = seg * (1-gt)
        fp = torch.sum(torch.sum(torch.sum(fpmult, dim=0, keepdim=True), dim=2, keepdim=True), dim=3, keepdim=True).squeeze()
        fnmult = (1-seg) * (gt)
        fn = torch.sum(torch.sum(torch.sum(fnmult, dim=0, keepdim=True), dim=2, keepdim=True), dim=3, keepdim=True).squeeze()
        self.tp += tp.double().cpu()
        self.fp += fp.double().cpu()
        self.fn += fn.double().cpu()

    def getIoU(self):
        num = self.tp
        den = self.tp + self.fp + self.fn + 1e-15
        iou = num / den
        return iou
    
    def getPRF1(self):
        precision = self.tp / (self.tp + self.fp + 1e-15)
        recall = self.tp / (self.tp + self.fn + 1e-15)
        f1 = (2 * precision * recall) / (precision + recall + 1e-15)

        return precision, recall, f1

class MyDataset(Dataset):

    def __init__(self, root_dir, transform, json_path):
        self.root_dir = root_dir
        self.img_dir = os.path.join(root_dir, 'selfimages')
        self.gt_dir = os.path.join(root_dir, 'selfgroundtruth1')
        self.image_list = [f for f in os.listdir(self.img_dir) if (f.endswith('.png'))]
        self.transform = transform

        if json_path:
            self.classes = json.load(open(json_path))['classes']

    def __len__(self):
        return len(self.image_list)
    
    def __getitem__(self, idx):
        img_name = os.path.join(self.img_dir, self.image_list[idx])
        gt_name = os.path.join(self.gt_dir, self.image_list[idx])
        image = Image.open(img_name)
        
        gt = Image.open(gt_name)

        if self.transform:
            
            image, gt = self.transform(image, gt)

        return image, gt.unsqueeze(0)
    
# class EarlyStopping:

#     def __init__(self, save_path, patience = 500, verbose = False, delta = 0.003):
        
#         self.save_path = save_path
#         self.patience = patience
#         self.verbose = verbose
#         self.counter = 0
#         self.best_score = None
#         self.early_stop = False
#         self.val_loss_min = np.Inf
#         self.delta = delta
    
#     def __call__(self, val_loss, model):

#         score = sum(val_loss) / len(val_loss)
#         #score = -val_loss

#         if self.best_score is None:
#             self.best_score = score
#             self.save_checkpoint(val_loss, model)
#         elif score < self.best_score + self.delta:
#             self.counter += 1
#             print(f'EarlyStopping countert: {self.counter} out of {self.patience}')
#             if self.counter >= self.patience:
#                 self.early_stop = True
        
#         else:
#             self.best_score = score
#             self.save_checkpoint(val_loss, model)
#             self.counter = 0
    
#     def save_checkpoint(self, val_loss, model):
#         if self.verbose:
#             print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}). Saving model ...')
#         path = os.path.join(self.save_path, 'best_network.pth')
#         torch.save(model.state_dict(), path)
#         self.val_loss_min = val_loss

use_gpu = torch.cuda.is_available()
writer = SummaryWriter(temp_dir)

save_path = '/media/deep/instrument_seg/copy_of_2e419_2023.11.23_all_files/new_workplace_2023_for_Surg_Net'
# early_stopping = EarlyStopping(save_path)
train_losses = []
val_losses = []
time_taken = []

def main():
    
    data_transforms = {
        'train' : Compose([
                Resize((256, 256)),
                RandomHorizontalFlip(flip_prob=0.2),
                RandomVerticalFlip(0.2),
                RandomRotation(180),
                ToTensor(),
            ]),
        'test' : Compose([
                Resize((256, 256)),
                ToTensor(),
        ]),
    }

    
    data_dir = '/media/deep/instrument_seg/data_endovis17/selfbuilder'
    
    json_path = '/media/deep/instrument_seg/data_endovis17/endovis2017Classes.json'
    image_datasets = {x: MyDataset(os.path.join(data_dir, x), data_transforms[x], json_path) for x in ['train', 'test']}
    dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size = 16, shuffle = True, num_workers = 4) for x in ['train', 'test']}

    classes = image_datasets['train'].classes
    key = disentangleKey(classes)
    num_classes = len(key)

    model = Comprehensive_Atten_Unet(args=2)

    optimizer = optim.Adam(model.parameters(), lr = 1e-4, weight_decay = 0.0005)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size = 10, gamma = 0.5)
    if use_gpu:
        model.cuda()
    
    evaluator = Evaluate(key, use_gpu)
    
    for epoch in range(0, 500):
        print('>>>>>>>>>>>>>>>>>>>>>>>Training<<<<<<<<<<<<<<<<<<<<<<<')
        train(dataloaders['train'], model, optimizer, scheduler, epoch, key)

        print('>>>>>>>>>>>>>>>>>>>>>>>Testing<<<<<<<<<<<<<<<<<<<<<<<')
        validate(dataloaders['test'], model, epoch, key, evaluator)
        
        # early_stopping(val_losses, model)
        # if early_stopping.early_stop:
        #     print('Early Stopping')
        #     break

        path = os.path.join(save_path, 'best_network.pth')
        torch.save(model.state_dict(), path)

        print('>>>>>>>>>>>>>>>>>> Evaluating the Metrics <<<<<<<<<<<<<<<<<')
        IoU = evaluator.getIoU()
        print('Mean IoU: {}, Class-wise IoU: {}'.format(torch.mean(torch.tensor(IoU)), IoU))
        PRF1 = evaluator.getPRF1()
        precision, recall, F1 = PRF1[0], PRF1[1], PRF1[2]
        print('Mean Precision: {}, Class-wise Precision: {}'.format(torch.mean(precision), precision))
        print('Mean Recall: {}, Class-wise Recall: {}'.format(torch.mean(recall), recall))
        print('Mean F1: {}, Class-wise F1: {}'.format(torch.mean(F1), F1))
        evaluator.reset()
        
        writer.add_scalar('IoU', torch.mean(torch.tensor(IoU)), epoch)
        writer.add_scalar('Pre', torch.mean(precision), epoch)
        writer.add_scalar('Rec', torch.mean(recall), epoch)
        writer.add_scalar('F1', torch.mean(F1), epoch)

    writer.close()

def train(train_Loader, model, optimizer, scheduler, epoch, key):

    model.train()
    train_loss = 0

    for i, (img, gt) in enumerate(train_Loader):

        
        gt_temp = gt * 255
        label = generateLabel4CE(gt_temp, key)

        if use_gpu:
            img = img.cuda()
            label = label.cuda()
        
        seg = model(img)
        loss = dice_loss(seg, label)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        scheduler.step(loss.mean())
        train_loss += loss.item()
        train_losses.append(train_loss / len(train_Loader))

        print('[%d/%d][%d/%d] Loss: %.4f lr:%.6f'
              % (epoch, 500-1, i, len(train_Loader)-1, loss.mean(),optimizer.state_dict()['param_groups'][0]['lr']))
        writer.add_scalar('trainloss', loss.mean(), epoch*len(train_Loader)+i)
        displaySamples(img, seg, gt, use_gpu, key, False, epoch, i, temp_dir)

def validate(val_loader, model, epoch, key, evaluator):
    
    model.eval()
    val_loss = 0

    for i, (img, gt) in enumerate(val_loader):

        
        gt_temp = gt * 255
        label = generateLabel4CE(gt_temp, key)
        oneHotGT = generateOneHot(gt_temp, key)
        #img, label = Variable(img), Variable(label)

        if use_gpu:
            img = img.cuda()
            label = label.cuda()
        
        with torch.no_grad():
            start_time = time.time()

            seg = model(img)

            end_time = time.time() - start_time
            time_taken.append(end_time)
            print("{:.10f}".format(end_time))

        
        loss = dice_loss(seg, label)
        val_loss += loss.item()
        val_losses.append(val_loss / len(val_loader))
        print('[%d/%d][%d/%d] Loss: %.4f'
              % (epoch, 500-1, i, len(val_loader)-1, loss.mean()))
        writer.add_scalar('validateloss', loss.mean(), epoch*len(val_loader)+i)
        displaySamples(img, seg, gt, use_gpu, key, True, epoch,
                             i, temp_dir)
        evaluator.addBatch(seg, oneHotGT)
    
    mean_time_taken = np.mean(time_taken)
    mean_fps = 1/mean_time_taken
    print("Mean FPS: ", mean_fps)
    writer.add_scalar('FPS', mean_fps, epoch)

if __name__ == '__main__':
    main()

#copy from 2023.9.11 and modified in 2023.9.16