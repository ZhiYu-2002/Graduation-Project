import torch
import argparse
from utils_for_present3 import disentangleKey, convertToOneHot, normalize, generateOneHot, displaySamples, reverseOneHot, generateLabel4CE
#from dice_losscopy3 import dice_loss
from torch.utils.tensorboard import SummaryWriter
from utils import DiceLoss

use_gpu = torch.cuda.is_available()
train_losses = []
temp_dir = '/media/deep/instrument_seg/copy_of_2e419_2023.11.23_all_files/new_workplace_2023_for_TransUNet/tmp'
writer = SummaryWriter(temp_dir)

parser = argparse.ArgumentParser()
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')
args = parser.parse_args()

def train(train_Loader, model, optimizer, scheduler, epoch, key):

    num_classes = args.num_classes

    model.train()
    train_loss = 0

    for i, (img, gt) in enumerate(train_Loader):

        img = img.view(-1, 3, 256, 256)
        img = normalize(img, torch.Tensor([0.295, 0.204, 0.197]), torch.Tensor([0.221, 0.188, 0.182]))
        gt = gt.view(-1, 1, 256, 256)
        gt_temp = gt * 255
        label = generateLabel4CE(gt_temp, key)
        #img, label = Variable(img), Variable(label)

        if use_gpu:
            img = img.cuda()
            label = label.cuda()
        
        seg = model(img)
        diceloss1 = DiceLoss(num_classes)
        loss = diceloss1(seg, label, softmax=True)
        #loss = DiceLoss(seg, label)
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        scheduler.step(loss.mean())
        train_loss += loss.item()
        train_losses.append(train_loss / len(train_Loader))

        print('[%d/%d][%d/%d] Loss: %.4f lr:%.6f'
              % (epoch, 500-1, i, len(train_Loader)-1, loss.mean(),optimizer.state_dict()['param_groups'][0]['lr']))
        writer.add_scalar('trainloss', loss.mean(), epoch*len(train_Loader)+i)
        displaySamples(img, seg, gt, use_gpu, key, False, epoch, i, temp_dir)

#modified in 2023.9.24