import torch
import argparse
from utils_for_present3 import disentangleKey, convertToOneHot, normalize, generateOneHot, displaySamples, reverseOneHot, generateLabel4CE
#from dice_losscopy3 import dice_loss
from torch.utils.tensorboard import SummaryWriter
import os
import numpy as np
from utils import DiceLoss

use_gpu = torch.cuda.is_available()
val_losses = []
temp_dir = 'F:/copy_of_2e417_working_station/tmp'
writer = SummaryWriter(temp_dir)

parser = argparse.ArgumentParser()
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')
args = parser.parse_args()

def validate(val_loader, model, epoch, key, evaluator):
    
    num_classes = args.num_classes

    model.eval()
    val_loss = 0

    for i, (img, gt) in enumerate(val_loader):

        img = img.view(-1, 3, 256, 256)
        img = normalize(img, torch.Tensor([0.295, 0.204, 0.197]), torch.Tensor([0.221, 0.188, 0.182]))
        gt = gt.view(-1, 1, 256, 256)
        gt_temp = gt * 255
        label = generateLabel4CE(gt_temp, key)
        oneHotGT = generateOneHot(gt_temp, key)
        #img, label = Variable(img), Variable(label)

        if use_gpu:
            img = img.cuda()
            label = label.cuda()
        
        seg = model(img)
        diceloss1 = DiceLoss(num_classes)
        loss = diceloss1(seg, label, softmax=True)
        #loss = DiceLoss(seg, label)
        val_loss += loss.item()
        val_losses.append(val_loss / len(val_loader))
        print('[%d/%d][%d/%d] Loss: %.4f'
              % (epoch, 500-1, i, len(val_loader)-1, loss.mean()))
        writer.add_scalar('validateloss', loss.mean(), epoch*len(val_loader)+i)
        displaySamples(img, seg, gt, use_gpu, key, True, epoch,
                             i, temp_dir)
        evaluator.addBatch(seg, oneHotGT)
""""
class EarlyStopping:

    def __init__(self, save_path, patience = 30, verbose = False, delta = 0.003):
        
        self.save_path = save_path
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
    
    def __call__(self, val_loss, model):

        score = sum(val_loss) / len(val_loss)
        #score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping countert: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0
    
    def save_checkpoint(self, val_loss, model):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}). Saving model ...')
        path = os.path.join(self.save_path, 'best_network.pth')
        torch.save(model.state_dict(), path)
        self.val_loss_min = val_loss
"""
#The transport of val_losses between validation and earlystopping is invalid, needing more modifying
#Since data is insufficient and epoch is samll, we dismiss earlystopping in this file (2023.9.19)
#wrote the diceloss with resource code method, the problem has been solved, but the .pth file should be saved and it has been wrote in ->
#earlystopping, so earlystopping was added again, and the validation was added so that earlystopping could run normally
#if you think the model does not need to save, you can also ignore the warning and use this file to run the 2023.9.19 with this validation
#modified in 2023.9.24