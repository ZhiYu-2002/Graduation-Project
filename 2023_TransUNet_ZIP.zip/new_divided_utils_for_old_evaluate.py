import torch
from utils_for_present3 import disentangleKey, convertToOneHot, normalize, generateOneHot, displaySamples, reverseOneHot, generateLabel4CE
class Evaluate():
    
    def __init__(self, num_classes, use_gpu):
        self.num_classes = num_classes
        self.use_gpu = use_gpu
        self.reset()
    
    def reset(self):
        self.tp = 0
        self.fp = 0
        self.fn = 0

    def addBatch(self, seg, gt):
        seg = convertToOneHot(seg, self.use_gpu).byte()
        seg = seg.float()
        gt = gt.float()
    
        if not self.use_gpu:
            seg = seg.cuda()
            gt = gt.cuda()
        
        tpmult = seg * gt
        tp = torch.sum(torch.sum(torch.sum(tpmult, dim = 0, keepdim = True), dim = 2, keepdim = True), dim = 3, keepdim = True).squeeze()
        fpmult = seg * (1-gt)
        fp = torch.sum(torch.sum(torch.sum(fpmult, dim=0, keepdim=True), dim=2, keepdim=True), dim=3, keepdim=True).squeeze()
        fnmult = (1-seg) * (gt)
        fn = torch.sum(torch.sum(torch.sum(fnmult, dim=0, keepdim=True), dim=2, keepdim=True), dim=3, keepdim=True).squeeze()
        self.tp += tp.double().cpu()
        self.fp += fp.double().cpu()
        self.fn += fn.double().cpu()

    def getIoU(self):
        num = self.tp
        den = self.tp + self.fp + self.fn + 1e-15
        iou = num / den
        return iou
    
    def getPRF1(self):
        precision = self.tp / (self.tp + self.fp + 1e-15)
        recall = self.tp / (self.tp + self.fn + 1e-15)
        f1 = (2 * precision * recall) / (precision + recall + 1e-15)

        return precision, recall, f1
