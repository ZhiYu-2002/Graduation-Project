import torch
import numpy as np
import torch.nn as nn
import cv2
import os

def disentangleKey(key):

    dKey = {}
    for i in range(len(key)):
        class_id = int(key[i]['id'])
        c = key[i]['color']
        c = c.split(',')
        c0 = int(c[0][1:])
        c1 = int(c[1])
        c2 = int(c[2][:-1])
        color_array = np.asarray([c0,c1,c2])
        dKey[class_id] = color_array

    return dKey

def convertToOneHot(batch, use_gpu):

    if use_gpu:
        batch = batch.cpu()
    
    batch = batch.data.numpy()
    for i in range(len(batch)):
        vec = batch[i,:,:,:]
        idxs = np.argmax(vec, axis=0)

        single = np.zeros([1, batch.shape[2], batch.shape[3]])
        
        for k in range(batch.shape[1]):
            mask = idxs == k
            mask = np.expand_dims(mask, axis=0)
            single = np.concatenate((single, mask), axis=0)

        single = np.expand_dims(single[1:,:,:], axis=0)
        if 'oneHot' in locals():
            oneHot = np.concatenate((oneHot, single), axis=0)
        else:
            oneHot = single

    oneHot = torch.from_numpy(oneHot.astype(np.uint8))
    return oneHot

def normalize(batch, mean, std):
    
    mean.unsqueeze_(1).unsqueeze_(1)
    std.unsqueeze_(1).unsqueeze_(1)
    for i in range(len(batch)):
        img = batch[i,:,:,:]
        img = img.sub(mean).div(std).unsqueeze(0)

        if 'concat' in locals():
            concat = torch.cat((concat, img), 0)
        else:
            concat = img

    return concat

def generateOneHot(gt, key):

    batch = gt.numpy()

    for i in range(len(batch)):
        img = batch[i,:,:,:]
        img = np.transpose(img, (1,2,0))
        catMask = np.zeros((img.shape[0], img.shape[1]))

        for k in range(len(key)):
            catMask = catMask * 0
            rgb = key[k]
            mask = np.where(np.all(img == rgb, axis = -1))
            catMask[mask] = 1

            catMaskTensor = torch.from_numpy(catMask).unsqueeze(0)
            if 'oneHot' in locals():
                oneHot = torch.cat((oneHot, catMaskTensor), 0)
            else:
                oneHot = catMaskTensor

    label = oneHot.view(len(batch),len(key),img.shape[0],img.shape[1])
    return label

def displaySamples(img, generated, gt, use_gpu, key, save, epoch, imageNum,
    save_dir):

    if use_gpu:
        img = img.cpu()
        generated = generated.cpu()

    gt = gt.numpy()
    
    gt = np.transpose((gt[0,:,:,:]), (1,2,0))
    gt = cv2.cvtColor(gt, cv2.COLOR_BGR2RGB)
    
    generated = generated.data.numpy()
    generated = reverseOneHot(generated, key)
    
    generated = (np.squeeze(generated[0,:,:,:])).astype(np.uint8)
    generated = cv2.cvtColor(generated, cv2.COLOR_BGR2RGB) / 255.0

    img = img.data.numpy()
    img = np.transpose(np.squeeze(img[0,:,:,:]), (1,2,0))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    stacked = np.concatenate((img, generated, gt), axis = 1)

    if save:
        file_name = 'epoch_%d_img_%d.png' %(epoch, imageNum)
        save_path = os.path.join(save_dir, file_name)
        cv2.imwrite(save_path, stacked*255.0)

    cv2.namedWindow('Input | Gen | GT', cv2.WINDOW_NORMAL)
    cv2.imshow('Input | Gen | GT', stacked)

    cv2.waitKey(1)

def reverseOneHot(batch, key):

    for i in range(len(batch)):
        vec = batch[i,:,:,:]
        idxs = np.argmax(vec, axis=0)

        #mean_val=np.sum(vec)/(vec.shape[0]*vec.shape[1]*vec.shape[2])
        #tmp=np.zeros(vec.shape)
        #tmp[vec>mean_val]=1
        #idxs=np.argmax(vec,axis=0)


        segSingle = np.zeros([idxs.shape[0], idxs.shape[1], 3])

        for k in range(len(key)):
            rgb = key[k]
            mask = idxs == k

            segSingle[mask] = rgb

        segMask = np.expand_dims(segSingle, axis=0)
        if 'generated' in locals():
            generated = np.concatenate((generated, segMask), axis=0)
        else:
            generated = segMask

    return generated

def generateLabel4CE(gt, key):

    batch = gt.numpy()
    
    for i in range(len(batch)):
        img = batch[i,:,:,:]
        img = np.transpose(img, (1,2,0))
        catMask = np.zeros((img.shape[0], img.shape[1]))

        for k in range(len(key)):
            rgb = key[k]
            mask = np.where(np.all(img == rgb, axis = 2))
            catMask[mask] = k

        catMaskTensor = torch.from_numpy(catMask).unsqueeze(0)
        if 'label' in locals():
            label = torch.cat((label, catMaskTensor), 0)
        else:
            label = catMaskTensor

    return label.long()