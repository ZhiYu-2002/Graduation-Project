# This is a new designed newwork based on ColonSegNet and TransResUNet.
# The encoder part derives from the former, while the decoder derives from the latter.

# from ColonSegNet

import torch
import torch.nn as nn
import torchvision.models as models
import torch
import torch.nn as nn
import numpy as np
import cv2
# from cbam_attention_copy import ResBlock_CBAM

class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        self.fc = nn.Sequential(
            nn.Linear(channel, int(channel / reduction), bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(int(channel / reduction), channel, bias=False),
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        p = self.avg_pool(x).view(b, c)
        y = self.fc(p).view(b, c, 1, 1)
        y = self.sigmoid(y)
        return x * y.expand_as(x)

class ResidualBlock_from_ColonSegNet_part1(nn.Module):
    def __init__(self, in_c, out_c):
        super(ResidualBlock_from_ColonSegNet_part1, self).__init__()

        self.conv1 = nn.Conv2d(in_c, out_c, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_c)

        self.conv2 = nn.Conv2d(out_c, out_c, kernel_size=3, stride=2, padding=1)
        self.bn2 = nn.BatchNorm2d(out_c)

        self.conv3 = nn.Conv2d(in_c, out_c, kernel_size=3, stride=2, padding=1)
        self.bn3 = nn.BatchNorm2d(out_c)
        self.se = SELayer(out_c)

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x1 = self.conv1(x)
        x1 = self.bn1(x1)
        x1 = self.relu(x1)

        x2 = self.conv2(x1)
        x2 = self.bn2(x2)

        x3 = self.conv3(x)
        x3 = self.bn3(x3)
        x3 = self.se(x3)

        x4 = x2 + x3
        x4 = self.relu(x4)

        return x4

class ResidualBlock_from_ColonSegNet_part2(nn.Module):
    def __init__(self, in_c, out_c):
        super(ResidualBlock_from_ColonSegNet_part2, self).__init__()

        self.conv1 = nn.Conv2d(in_c, out_c, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_c)

        self.conv2 = nn.Conv2d(out_c, out_c, kernel_size=3, stride=2, padding=1)
        self.bn2 = nn.BatchNorm2d(out_c)

        self.conv3 = nn.Conv2d(in_c, out_c, kernel_size=3, stride=2, padding=1)
        self.bn3 = nn.BatchNorm2d(out_c)
        self.se = SELayer(out_c)

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x1 = self.conv1(x)
        x1 = self.bn1(x1)
        x1 = self.relu(x1)

        x2 = self.conv2(x1)
        x2 = self.bn2(x2)

        x3 = self.conv3(x)
        x3 = self.bn3(x3)
        x3 = self.se(x3)

        x4 = x2 + x3
        x4 = self.relu(x4)

        return x4

class StridedConvBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super(StridedConvBlock, self).__init__()

        self.conv = nn.Conv2d(in_c, out_c, kernel_size=(3, 3), stride=1, padding=1)
        self.bn = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class EncoderBlock_from_ColonSegNet_part1(nn.Module):
    def __init__(self, in_c, out_c):
        super(EncoderBlock_from_ColonSegNet_part1, self).__init__()

        self.residual_block1 = ResidualBlock_from_ColonSegNet_part1(in_c, out_c//4)
        self.strided_conv = StridedConvBlock(out_c//4, out_c//4)
        self.residual_block2 = ResidualBlock_from_ColonSegNet_part2(out_c//4, out_c)
        self.pooling = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x1 = self.residual_block1(x)
        x2 = self.strided_conv(x1)
        x3 = self.residual_block2(x2)
        p = self.pooling(x3)
        return x1, x3, p

class EncoderBlock_from_ColonSegNet_part2(nn.Module):
    def __init__(self, in_c, out_c):
        super(EncoderBlock_from_ColonSegNet_part2, self).__init__()

        self.residual_block1 = ResidualBlock_from_ColonSegNet_part1(in_c, out_c//2)
        self.strided_conv = StridedConvBlock(out_c//2, out_c//2)
        self.residual_block2 = ResidualBlock_from_ColonSegNet_part2(out_c//2, out_c)
        self.pooling = nn.MaxPool2d(kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x1 = self.residual_block1(x)
        x2 = self.strided_conv(x1)
        x3 = self.residual_block2(x2)
        p = self.pooling(x3)
        return x1, x3, p

#from transresunet
def save_feats_mean(x):
    b, c, h, w = x.shape
    if h == 256:
        with torch.no_grad():
            x = x.detach().cpu().numpy()
            x = np.transpose(x[0], (1, 2, 0))
            x = np.mean(x, axis=-1)
            x = x/np.max(x)
            x = x * 255.0
            x = x.astype(np.uint8)
            x = cv2.applyColorMap(x, cv2.COLORMAP_JET)
            x = np.array(x, dtype=np.uint8)
            return x

#from surg_net
class residual_block(nn.Module):
    def __init__(self, ch_in):
        super(residual_block, self).__init__()
        self.conv3 = nn.Sequential(
            nn.Conv2d(ch_in, ch_in, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(ch_in)
        )
        self.conv1 = nn.Sequential(
            nn.Conv2d(ch_in, ch_in, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(ch_in)
        )
        self.relu = nn.ReLU(inplace=True)
        
    def forward(self, x):
        x1 = self.conv3(x)
        x2 = self.conv1(x)
        x3 = x1 + x2
        x = self.relu(x3)
        return x

#from transresunet
class ResidualBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.relu = nn.ReLU()
        self.conv = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU(),
            nn.Conv2d(out_c, out_c, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_c)
        )
        self.shortcut = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=1, padding=0),
            nn.BatchNorm2d(out_c)
        )

    def forward(self, inputs):
        x1 = self.conv(inputs)
        x2 = self.shortcut(inputs)
        x = self.relu(x1 + x2)
        return x

#from transresunet
class EncoderBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.r1 = ResidualBlock(in_c, out_c)
        self.pool = nn.MaxPool2d((2, 2))

    def forward(self, inputs):
        x = self.r1(inputs)
        p = self.pool(x)
        return x, p

#from transresunet
class Bottleneck(nn.Module):
    def __init__(self, in_c, out_c, dim, num_layers=2):
        super().__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=1, padding=0),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

        encoder_layer = nn.TransformerEncoderLayer(d_model=dim, nhead=8)
        self.tblock = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        self.conv2 = nn.Sequential(
            nn.Conv2d(out_c, out_c, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

    def forward(self, x):
        x = self.conv1(x)
        b, c, h, w = x.shape
        x = x.reshape((b, c, h*w))
        x = self.tblock(x)
        x = x.reshape((b, c, h, w))
        x = self.conv2(x)
        return x

#from transresunet
class DilatedConv(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.c1 = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=1, dilation=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

        self.c2 = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=3, dilation=3),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

        self.c3 = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=6, dilation=6),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

        self.c4 = nn.Sequential(
            nn.Conv2d(in_c, out_c, kernel_size=3, padding=9, dilation=9),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

        self.c5 = nn.Sequential(
            nn.Conv2d(out_c*4, out_c, kernel_size=1, padding=0),
            nn.BatchNorm2d(out_c),
            nn.ReLU()
        )

    def forward(self, inputs):
        x1 = self.c1(inputs)
        x2 = self.c2(inputs)
        x3 = self.c3(inputs)
        x4 = self.c4(inputs)
        x = torch.cat([x1, x2, x3, x4], axis=1)
        x = self.c5(x)
        return x

#from transresunet
class DecoderBlock1(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)

        
        self.conv1 = nn.Conv2d(in_c[0], in_c[0]*2, kernel_size=7, stride=2, padding=3)

        self.r1 = ResidualBlock(in_c[1]*2, out_c)
        self.r2 = ResidualBlock(out_c, out_c)

    def forward(self, inputs, skip):
        x = self.up(inputs)
        x = self.conv1(x)
        x = torch.cat([x, skip], axis=1)
        x = self.r1(x)
        x = self.r2(x)
        return x

class DecoderBlock2(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)

        

        self.r1 = ResidualBlock(in_c[0]+in_c[1], out_c)
        self.r2 = ResidualBlock(out_c, out_c)

    def forward(self, inputs, skip):
        x = self.up(inputs)
        # x = self.conv1(x)
        x = torch.cat([x, skip], axis=1)
        x = self.r1(x)
        x = self.r2(x)
        return x

class DecoderBlock3(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)

        self.r1 = ResidualBlock(in_c[0]+in_c[1], out_c)
        self.r2 = ResidualBlock(out_c, out_c)

    def forward(self, inputs, skip):
        x = self.up(inputs)
        # x = self.conv1(x)
        x = torch.cat([x, skip], axis=1)
        x = self.r1(x)
        x = self.r2(x)
        return x

class DecoderBlock4(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()

        self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)

        self.r1 = ResidualBlock(in_c[0]+in_c[1], out_c)
        self.r2 = ResidualBlock(out_c, out_c)

    def forward(self, inputs, skip):
        x = self.up(inputs)
        # x = self.conv1(x)
        x = torch.cat([x, skip], axis=1)
        x = self.r1(x)
        x = self.r2(x)
        return x

#from transresunet
class NewNet4(nn.Module):
    def __init__(self):
        super().__init__()

        # """ ResNet50 """
        # backbone = resnet50()
        # self.layer0 = nn.Sequential(backbone.conv1, backbone.bn1, backbone.relu)
        # self.layer1 = nn.Sequential(backbone.maxpool, backbone.layer1)
        # self.layer2 = backbone.layer2
        # self.layer3 = backbone.layer3

        """ ColonSegNet_Backbone """
        self.layer0 = EncoderBlock_from_ColonSegNet_part1(3, 256)
        self.layer1 = EncoderBlock_from_ColonSegNet_part2(256, 1024)

        # """ residual_block """
        # self.residual1 = residual_block(64)
        # self.residual2 = residual_block(256)
        # self.residual3 = residual_block(512)
        # self.residual4 = residual_block(1024)

        # """ ResBlock_CBAM """
        # self.cbam1 = ResBlock_CBAM(in_places=64, places=16)
        # self.cbam2 = ResBlock_CBAM(in_places=256, places=64)
        # self.cbam3 = ResBlock_CBAM(in_places=512, places=128)
        # self.cbam4 = ResBlock_CBAM(in_places=1024, places=256)

        """ Bridge blocks """
        self.b1 = Bottleneck(1024, 256, 256, num_layers=2)
        self.b2 = DilatedConv(1024, 256)

        """ Decoder """
        self.d1 = DecoderBlock1([512, 1024], 256)
        self.d2 = DecoderBlock2([256, 512], 128)
        self.d3 = DecoderBlock3([128, 256], 64)
        self.d4 = DecoderBlock4([64, 64], 32)

        self.finalup = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        self.output = nn.Conv2d(32, 2, kernel_size=1)

    def forward(self, x, heatmap=None):

        s0 = x
        # print(s0.shape)

        s11, s12, p1 = self.layer0(s0)
        # print(s11.shape)
        # print(s12.shape)
        # print(p1.shape)
        
        s21, s22, p2 = self.layer1(p1)
        # print(s21.shape)
        # print(s22.shape)
        # print(p2.shape)


        # cb4 = self.cbam4(s22)
        # print(cb4.shape)
        # cb3 = self.cbam3(s21)
        # print(cb3.shape)
        # cb2 = self.cbam2(s12)
        # print(cb2.shape)
        # cb1 = self.cbam1(s11)
        # print(cb1.shape)


        b1 = self.b1(p2)
        # print(b1.shape)
        b2 = self.b2(p2)
        # print(b2.shape)
        b3 = torch.cat([b1, b2], axis=1)
        # print(b3.shape)


        d1 = self.d1(b3, s22)
        # print(d1.shape)
        d2 = self.d2(d1, s21)
        # print(d2.shape)
        d3 = self.d3(d2, s12)
        # print(d3.shape)
        d4 = self.d4(d3, s11)
        # print(d4.shape)


        w = self.finalup(d4)
        # print(w.shape)
        y = self.output(w)
        # print(y.shape)

        if heatmap != None:
            hmap = save_feats_mean(d4)
            return hmap, y
        else:
            return y

# if __name__ == "__main__":
#     x = torch.randn((4, 3, 256, 256))
#     model = NewNet4()
#     y = model(x)
#     print(y.shape)

